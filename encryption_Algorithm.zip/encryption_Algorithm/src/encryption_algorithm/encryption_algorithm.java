/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package encryption_algorithm;
import java.util.Random;
import java.util.Scanner;
import java.security.MessageDigest;

public class encryption_algorithm {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random random = new Random();

        System.out.print("Enter your message: ");
        String message = input.nextLine();
        int key = random.nextInt(26); // Generate a random key for encryption

        // Encrypting the message
        String encryptedMessage = encrypt(message, key);
        System.out.println("Encrypted Message: " + encryptedMessage);

        // Converting to binary
        String binaryMessage = toBinary(encryptedMessage);
        System.out.println("Binary Representation: " + binaryMessage);

        // Rotating binary
        String rotatedBinary = rightRotate(binaryMessage, 2);
        System.out.println("Rotated Binary: " + rotatedBinary);

        // Adding random bits
        String augmentedBinary = addTo(rotatedBinary);
        System.out.println("Augmented Binary: " + augmentedBinary);

        // Converting back to string
        String finalMessage = binaryToString(augmentedBinary);
        System.out.println("Final Text from Binary: " + finalMessage);

        // Hashing for integrity
        try {
            String hash = computeHash(encryptedMessage);
            System.out.println("Integrity Hash (SHA-256): " + hash);
        } catch (Exception e) {
            System.out.println("Error computing hash: " + e.getMessage());
        }

        // Decrypting the message
        String decryptedMessage = decrypt(encryptedMessage, key);
        System.out.println("Decrypted Message: " + decryptedMessage);
    }

    public static String encrypt(String message, int key) {
        StringBuilder ciphertext = new StringBuilder();
        for (int i = 0; i < message.length(); i++) {
            char character = message.charAt(i);
            if (Character.isUpperCase(character)) {
                int decimalValue = ((int) character - 'A' + key) % 26;
                character = (char) (decimalValue + 'A');
            } else if (Character.isLowerCase(character)) {
                int decimalValue = ((int) character - 'a' + key) % 26;
                character = (char) (decimalValue + 'a');
            } else if (Character.isDigit(character)) {
                int decimalValue = ((int) character - '0' + key) % 10;
                character = (char) (decimalValue + '0');
            }
            ciphertext.append(character);
        }
        return ciphertext.toString();
    }

    public static String decrypt(String ciphertext, int key) {
        StringBuilder decryptedText = new StringBuilder();
        for (int i = 0; i < ciphertext.length(); i++) {
            char character = ciphertext.charAt(i);
            if (Character.isUpperCase(character)) {
                int decimalValue = ((int) character - 'A' - key + 26) % 26;
                character = (char) (decimalValue + 'A');
            } else if (Character.isLowerCase(character)) {
                int decimalValue = ((int) character - 'a' - key + 26) % 26;
                character = (char) (decimalValue + 'a');
            } else if (Character.isDigit(character)) {
                int decimalValue = ((int) character - '0' - key + 10) % 10;
                character = (char) (decimalValue + '0');
            }
            decryptedText.append(character);
        }
        return decryptedText.toString();
    }

    public static String toBinary(String message) {
        StringBuilder binaryString = new StringBuilder();
        for (char c : message.toCharArray()) {
            String binaryChar = Integer.toBinaryString(c);
            while (binaryChar.length() < 8) {
                binaryChar = "0" + binaryChar;
            }
            binaryString.append(binaryChar);
        }
        return binaryString.toString();
    }

    public static String rightRotate(String binaryString, int rotationCount) {
        int n = binaryString.length();
        rotationCount %= n; // Ensure rotation count is within the string length
        String lastBits = binaryString.substring(n - rotationCount);
        String remainingBits = binaryString.substring(0, n - rotationCount);
        return lastBits + remainingBits; // Concatenate the last bits to the front
    }

    public static String addTo(String binaryString) {
        StringBuilder result = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < binaryString.length(); i += 8) {
            result.append(binaryString.substring(i, Math.min(i + 8, binaryString.length())));

            // Add 16 random bits
            for (int j = 0; j < 16; j++) {
                result.append(random.nextInt(2));
            }
        }
        return result.toString();
    }

    public static String binaryToString(String binaryString) {
        int length = binaryString.length() / 8;
        char[] result = new char[length];

        for (int i = 0; i < length; i++) {
            String byteString = binaryString.substring(i * 8, (i + 1) * 8);
            result[i] = (char) Integer.parseInt(byteString, 2);
        }
        return new String(result);
    }

    public static String computeHash(String input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(input.getBytes("UTF-8"));
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}